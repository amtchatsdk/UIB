package com.unified.inbox

import android.graphics.drawable.Drawable

internal interface UIBChatAdapterListener {

    fun setUserMessageTextSize(size: Float)
    fun setUserMessageTextStyle(style: Int)
    fun setBotMessageTextSize(size: Float)
    fun setBotMessageTextStyle(style: Int)
    fun setUserMessageTextColor(color: Int)
    fun setBotMessageTextColor(color: Int)
    fun setUserMessageTextBackground(background: Drawable)
    fun setSupportMessageTextBackground(background: Drawable)
    fun bindUserMessage(holder: UIBChatAdapter.UserMessageViewHolder, position: Int)
    fun bindBotMessage(holder: UIBChatAdapter.BotMessageViewHolder, position: Int)
    fun setMarginForUserText(adjustMargin: Boolean,left: Int, right: Int, top: Int, bottom: Int)
    fun setPaddingForUserText(adjustPadding: Boolean,left: Int, right: Int, top: Int, bottom: Int)
    fun setMarginForBotText(adjustMargin: Boolean,left: Int, right: Int, top: Int, bottom: Int)
    fun setPaddingForBotText(adjustPadding: Boolean,left: Int, right: Int, top: Int, bottom: Int)
}