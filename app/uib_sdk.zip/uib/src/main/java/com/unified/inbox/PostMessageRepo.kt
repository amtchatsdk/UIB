package com.unified.inbox

import com.google.gson.JsonObject
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

internal class PostMessageRepo(private var responseListener: OnResponseListener) {
    private var apiClient: APIClient? = null

    init {
        apiClient =
            RetrofitInstance().getRetrofitInstance("https://chatbot-v2connector.unificationengine.com/")
                .create(APIClient::class.java)
    }

    fun postMessage(message: JsonObject, appId: String, botId: String, userId: String) {

        val call: Call<PostMessageResponse>? = apiClient?.sendMessageRequest(
            message = message,
            appId = appId,
            botId = botId,
            userId = userId
        )
        call?.enqueue(object : Callback<PostMessageResponse> {
            override fun onResponse(
                call: Call<PostMessageResponse>,
                response: Response<PostMessageResponse>
            ) {
                responseListener.onSuccess(response)
            }

            override fun onFailure(call: Call<PostMessageResponse>, t: Throwable) {
                responseListener.onError(t)
            }
        })

    }

}