package com.unified.inbox

import android.util.Log
import com.star_zero.sse.EventHandler
import com.star_zero.sse.EventSource
import com.star_zero.sse.MessageEvent


internal class UIBConnection(private var uibEventListener: UIBEventListener) {

    private var eventSource: EventSource? = null
    fun connect(appId: String, botId: String, userId: String) {
        eventSource = EventSource(
            //Bhaskar  the appid to be changed is c9e0faed-0d1c-4580-a118-ad017811688a
            //The chatbot connector is deployed to live the url is
            //https://chatbot-v2connector.unificationengine.com
            //
            //
            //
            //Alos change messages api
            //https://chatbot-v2connector.unificationengine.com/app/c9e0faed-0d1c-4580-a118-ad017811688a/bot/123456/user/5e71ba3ba4c44a0e9f60854e/messages
            "https://chatbot-v2connector.unificationengine.com/app/${appId}/bot/${botId}/user/${userId}/notification",
            object : EventHandler {
                override fun onOpen() {
                    Log.d("message", "OPEN")
                }

                override fun onMessage(event: MessageEvent) {
                    Log.d("message", event.data)
                    uibEventListener.onEventResponse(event.data)
                }

                override fun onError(e: Exception?) {
                    e?.printStackTrace()
                    Log.e("message", e.toString())
                    uibEventListener.onEventError(e!!)
                }

            }
        )
        eventSource?.connect()
    }


    fun disposeEventSource() {
        eventSource?.close()
    }
}