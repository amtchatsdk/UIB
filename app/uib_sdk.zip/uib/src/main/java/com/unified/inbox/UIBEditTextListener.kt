package com.unified.inbox

import android.graphics.drawable.Drawable

internal interface UIBEditTextListener {
    fun setUIBSendIcon(icon: Drawable)
    fun setUIBSendButtonBackground(background: Drawable)
    fun setUIBEditTextHint(hint: String)
    fun setUIBEditTextBackground(background: Drawable)
    fun setUIBEditTextInputType(inputType: Int)
    fun setPaddingForEditText(adjustPadding: Boolean, left: Int, right: Int, top: Int, bottom: Int)
    /*fun setPaddingForEditTextContainer(
        adjustPadding: Boolean,
        left: Int,
        right: Int,
        top: Int,
        bottom: Int
    )*/

    fun setMarginForEditText(adjustMargin: Boolean, left: Int, right: Int, top: Int, bottom: Int)
    /*fun setMarginForEditTextContainer(
        adjustMargin: Boolean,
        left: Int,
        right: Int,
        top: Int,
        bottom: Int
    )*/

    fun showErrorMessageForEmptyValue(errorString: String)
    fun shouldShowErrorForEmptyMessage(value: Boolean)
    fun trimTypedMessage(value: Boolean)
    fun setUIBEditTextHintColor(color: Int)
}