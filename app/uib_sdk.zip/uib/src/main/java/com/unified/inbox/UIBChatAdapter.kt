package com.unified.inbox

import android.graphics.drawable.Drawable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

internal class UIBChatAdapter/*(*//*private var mCtx: FragmentActivity*//*)*/ :
    RecyclerView.Adapter<RecyclerView.ViewHolder>(), UIBChatAdapterListener {

    private val userMessageViewType: Int = 0
    private val botMessageViewType: Int = 1
    private var userMessageTextSize: Float? = 0.0f
    private var botMessageTextSize: Float? = 0.0f
    private var botMessageTextStyle: Int? = null
    private var userMessageTextStyle: Int? = null
    private var userMessageTextColor: Int? = null
    private var userMessageTextBackground: Drawable? = null
    private var botMessageTextColor: Int? = null
    private var botMessageTextBackground: Drawable? = null
    private var adjustUserTextMargin: Boolean? = false
    private var adjustUserTextPadding: Boolean? = false
    private var adjustBotTextMargin: Boolean? = false
    private var adjustBotTextPadding: Boolean? = false
    private var userTextMarginRight: Int? = null
    private var botTextMarginRight: Int? = null
    private var userTextMarginLeft: Int? = null
    private var botTextMarginLeft: Int? = null
    private var userTextMarginTop: Int? = null
    private var botTextMarginTop: Int? = null
    private var userTextMarginBottom: Int? = null
    private var botTextMarginBottom: Int? = null
    private var userTextPaddingRight: Int? = null
    private var botTextPaddingRight: Int? = null
    private var userTextPaddingLeft: Int? = null
    private var botTextPaddingLeft: Int? = null
    private var userTextPaddingTop: Int? = null
    private var botTextPaddingTop: Int? = null
    private var userTextPaddingBottom: Int? = null
    private var botTextPaddingBottom: Int? = null

    private var chatList: MutableList<Chat>? = null

    init {
        chatList = ArrayList()
    }

    fun addItem(chat: Chat) {
        chatList?.add(chat)
        notifyDataSetChanged()
    }

    override fun getItemViewType(position: Int): Int {
        return if (chatList?.get(position)?.from == 0) {
            userMessageViewType
        } else {
            botMessageViewType
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return if (viewType == userMessageViewType) {
            val mView: View =
                LayoutInflater.from(parent.context)
                    .inflate(R.layout.uib_chat_bubble_user, parent, false)
            UserMessageViewHolder(mView)
        } else {
            val mView: View =
                LayoutInflater.from(parent.context)
                    .inflate(R.layout.uib_chat_bubble_bot, parent, false)
            BotMessageViewHolder(mView)
        }
    }

    override fun getItemCount(): Int {
        return chatList?.size!!
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        if (holder is UserMessageViewHolder) {
            bindUserMessage(holder, position)

        } else if (holder is BotMessageViewHolder) {
            bindBotMessage(holder, position)
        }
    }

    inner class UserMessageViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var tvUserMsg: TextView? = null

        init {
            tvUserMsg = itemView.findViewById(R.id.tv_message_user)
        }
    }

    inner class BotMessageViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var tvBotMsg: TextView? = null

        init {
            tvBotMsg = itemView.findViewById(R.id.tv_message_bot)
        }
    }

    override fun setUserMessageTextSize(size: Float) {
        this.userMessageTextSize = size
    }

    override fun setUserMessageTextStyle(style: Int) {
        this.userMessageTextStyle = style
    }

    override fun setBotMessageTextSize(size: Float) {
        this.botMessageTextSize = size
    }

    override fun setBotMessageTextStyle(style: Int) {
        this.botMessageTextStyle = style
    }

    override fun setUserMessageTextColor(color: Int) {
        this.userMessageTextColor = color
    }

    override fun setBotMessageTextColor(color: Int) {
        this.botMessageTextColor = color
    }

    override fun setUserMessageTextBackground(background: Drawable) {
        this.userMessageTextBackground = background
    }

    override fun setSupportMessageTextBackground(background: Drawable) {
        this.botMessageTextBackground = background
    }

    override fun bindUserMessage(holder: UserMessageViewHolder, position: Int) {
        if (adjustUserTextMargin!!) {
            val params: ViewGroup.MarginLayoutParams =
                holder.tvUserMsg?.layoutParams as ViewGroup.MarginLayoutParams
            params.setMargins(
                userTextMarginLeft!!,
                userTextMarginTop!!,
                userTextMarginRight!!,
                userTextMarginBottom!!
            )
        }

        if (adjustUserTextPadding!!) {
            holder.tvUserMsg?.setPadding(
                userTextPaddingLeft!!,
                userTextPaddingTop!!,
                userTextPaddingRight!!,
                userTextPaddingBottom!!
            )
        }
        if (userMessageTextSize != 0.0f) {
            holder.tvUserMsg?.textSize = userMessageTextSize!!
        }
        if (userMessageTextStyle != null) {
            holder.tvUserMsg?.setTypeface(holder.tvUserMsg!!.typeface, userMessageTextStyle!!)
        }
        if (userMessageTextColor != null) {
            holder.tvUserMsg?.setTextColor(userMessageTextColor!!)
        }

        if (userMessageTextBackground != null) {
            holder.tvUserMsg?.background = userMessageTextBackground
        }

        holder.tvUserMsg?.text = chatList?.get(position)?.msg


    }

    override fun bindBotMessage(holder: BotMessageViewHolder, position: Int) {
        if (adjustBotTextMargin!!) {
            val params: ViewGroup.MarginLayoutParams =
                holder.tvBotMsg?.layoutParams as ViewGroup.MarginLayoutParams
            params.setMargins(
                botTextMarginLeft!!,
                botTextMarginTop!!,
                botTextMarginRight!!,
                botTextMarginBottom!!
            )
        }

        if (adjustBotTextPadding!!) {
            holder.tvBotMsg?.setPadding(
                botTextPaddingLeft!!,
                botTextPaddingTop!!,
                botTextPaddingRight!!,
                botTextPaddingBottom!!
            )
        }
        if (botMessageTextSize != 0.0f) {
            holder.tvBotMsg?.textSize = botMessageTextSize!!
        }
        if (botMessageTextStyle != null) {
            holder.tvBotMsg?.setTypeface(holder.tvBotMsg!!.typeface, botMessageTextStyle!!)
        }
        if (botMessageTextColor != null) {
            holder.tvBotMsg?.setTextColor(botMessageTextColor!!)
        }
        if (botMessageTextBackground != null) {
            holder.tvBotMsg?.background = botMessageTextBackground
        }
        holder.tvBotMsg?.text = chatList?.get(position)?.msg
    }

    override fun setMarginForUserText(
        adjustMargin: Boolean,
        left: Int,
        right: Int,
        top: Int,
        bottom: Int
    ) {
        this.adjustUserTextMargin = adjustMargin
        this.userTextMarginBottom = bottom
        this.userTextMarginLeft = left
        this.userTextMarginRight = right
        this.userTextMarginTop = top
    }

    override fun setPaddingForUserText(
        adjustPadding: Boolean,
        left: Int,
        right: Int,
        top: Int,
        bottom: Int
    ) {
        this.adjustUserTextPadding = adjustPadding
        this.userTextPaddingTop = top
        this.userTextPaddingRight = right
        this.userTextPaddingLeft = left
        this.userTextPaddingBottom = bottom
    }

    override fun setMarginForBotText(
        adjustMargin: Boolean,
        left: Int,
        right: Int,
        top: Int,
        bottom: Int
    ) {
        this.adjustBotTextMargin = adjustMargin
        this.botTextMarginTop = top
        this.botTextMarginRight = right
        this.botTextMarginLeft = left
        this.botTextMarginBottom = bottom
    }

    override fun setPaddingForBotText(
        adjustPadding: Boolean,
        left: Int,
        right: Int,
        top: Int,
        bottom: Int
    ) {
        this.adjustBotTextPadding = adjustPadding
        this.botTextPaddingBottom = bottom
        this.botTextPaddingLeft = left
        this.botTextPaddingRight = right
        this.botTextPaddingTop = top
    }
}