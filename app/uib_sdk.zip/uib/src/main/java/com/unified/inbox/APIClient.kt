package com.unified.inbox

import com.google.gson.JsonObject
import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.http.Path

internal interface APIClient {
    @POST("app/{appId}/bot/{botId}/user/{userId}/messages")
    fun sendMessageRequest(
        @Path("appId") appId: String,
        @Path("botId") botId: String,
        @Path("userId") userId: String,
        @Body message: JsonObject
    ): Call<PostMessageResponse>?
}