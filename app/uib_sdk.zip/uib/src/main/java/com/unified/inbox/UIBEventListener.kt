package com.unified.inbox

internal interface UIBEventListener {

    fun <T> onEventResponse(response: T)
    fun onEventError(error: Exception)
}